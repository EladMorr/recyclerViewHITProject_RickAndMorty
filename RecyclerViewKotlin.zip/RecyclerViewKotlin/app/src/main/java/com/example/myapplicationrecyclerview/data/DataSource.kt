package com.example.myapplicationrecyclerview.data

import com.example.myapplicationrecyclerview.models.BlogPost

class DataSource {

    companion object {

        fun createDataSet(): ArrayList<BlogPost> {
            val list = ArrayList<BlogPost>()
            list.add(
                BlogPost(
                    0,
                    "Rick Sanchez",
                    "A brilliant scientific but crazy maniac person, build a lot of new machines and grandfather of Morty.",
                    "https://www.gifcen.com/wp-content/uploads/2021/11/rick-and-morty-gif-10.gif",
                    "https://i.pinimg.com/originals/76/8d/35/768d35396583f38b1136a6d45b94cf7c.gif",
                    "Mark Justin Roiland"
                )
            )
            list.add(
                BlogPost(
                    1,
                    "Morty Smith",
                    "A scared kid who goes after his grandfather everywhere, lacks a backbone and is still scared to tell the love of his life how he feels.",
                    "https://static.wikia.nocookie.net/241a9afc-c47f-43ef-a7f2-f4d7d6bbb395",
                    "https://i.pinimg.com/originals/c1/f3/4b/c1f34bd8078ea98321bdee247c05b2cf.gif",
                    "Justin Roiland"
                )
            )

            list.add(
                BlogPost(
                    2,
                    "Summer Smith",
                    "A teenage girl, trying to be the cool girl of the class. Loves to annoy her little brother and tries to get Grandpa Rick's attention.",
                    "https://blog.lootcrate.com/wp-content/uploads/2018/06/tumblr_nv39mnrkSP1tjnfcso1_500.gif",
                    "https://i.gifer.com/6lhm.gif",
                    "Spencer Grammer"
                )
            )
            list.add(
                BlogPost(
                    3,
                    "Beth Smith",
                    "The mother of the family. Always looking for her dad's attention. Apparently she's a clone.",
                    "https://c.tenor.com/cM5E8CfpdZYAAAAd/rick-and-morty-beth.gif",
                    "https://i.redd.it/u0bojhq7g7qz.gif",
                    "Sarah Chalke"
                )
            )
            list.add(
                BlogPost(
                    4,
                    "Jerry Smith",
                    "The loser dad who interests no one, lacks a sense of humor, thinks he is the smartest when in practice he is the dumbest.",
                    "https://media0.giphy.com/media/MaxUtki5xQdQLwUPW1/giphy.gif?cid=63e6b07e2fpvr516zh4jdol61k3vbnwftujkfkx1hvizetbt&rid=giphy.gif&ct=g",
                    "https://data.whicdn.com/images/314588242/original.gif",
                    "Chris Parnell"
                )
            )
            list.add(
                BlogPost(
                    5,
                    "Squanchy",
                    "Rick's best friend, likes to do a lot of nonsense.",
                    "https://i.imgur.com/p1yN57F.gif?noredirect",
                    "https://thumbs.gfycat.com/NeglectedEnchantingEastsiberianlaika-size_restricted.gif",
                    "Thomas James Kenny"
                )
            )
            list.add(
                BlogPost(
                    6,
                    "Abrodolph Lincoler",
                    "Rick created a clone of Abraham Lincoln and Hitler. He half loves people and half wants to destroy humanity.",
                    "https://64.media.tumblr.com/eaf155197e4480a19127ed37fb24201e/tumblr_p5tbgdbvvB1wz0p72o1_540.gifv",
                    "https://media0.giphy.com/media/Qtk7fwKdKwWjFWPpGn/giphy.gif",
                    "Maurice LaMarche"
                )
            )

            return list
        }
    }
}